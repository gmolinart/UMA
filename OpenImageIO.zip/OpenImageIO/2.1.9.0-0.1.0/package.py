# -*- coding: utf-8 -*-

name = 'OpenImageIO'

version = '2.1.9.0-0.1.0'

description = 'Rez external package for OpenImageIO'

authors = ['https://github.com/OpenImageIO/oiio']

requires = []

build_requires = [
    'python-3',
    'rez_builder'
]

def commands():
    env.PYTHONPATH.append('{root}/python')
    env.PATH.append('{root}/python')
    
    alias("iconvert", "{root}/python/iconvert.exe")
    alias("idiff", "{root}/python/idiff.exe")
    alias("igrep", "{root}/python/igrep.exe")
    alias("iinfo", "{root}/python/iinfo.exe")
    alias("maketx", "{root}/python/maketx.exe")
    alias("oiiotool", "{root}/python/oiiotool.exe")

with scope('config') as config:
    config.release_packages_path = '${MARZ_REZ_PACKAGES_PATH_EXT}'

timestamp = 1639503608

release_message = \
    ('OpenImageIO first release package, added OpenColorIO module and python 3.7 '
     'compatibility')

changelog = \
    """
    commit 75a250cec10d1f0d56ce83545a0f9af92d3fe8ce
    Merge: 4c22713 6c724ec
    Author: Alejandro <91090128+alejcabrera@users.noreply.github.com>
    Date:   Tue Dec 14 12:32:40 2021 -0500
    
        Merge pull request #2 from marzvfx/hotfix/python_37_bindings_opencolor
    
        opencolorio bindings and python 3.7 compatibility
    
    commit 6c724ec1c45592e48e56956ea75d4016d7adca0d
    Author: Alejandro <91090128+alejcabrera@users.noreply.github.com>
    Date:   Mon Dec 13 17:03:22 2021 -0500
    
        Added studio_version package.py
    
        Co-authored-by: Nevil Sidhwa <90268099+NevsTD-MARZ@users.noreply.github.com>
    
    commit 1175f5583fe72e5c719a90071b52ddc2babc2ef7
    Author: Alejandro <91090128+alejcabrera@users.noreply.github.com>
    Date:   Mon Dec 13 17:00:24 2021 -0500
    
        Added spaces on package.py
    
        Co-authored-by: Nevil Sidhwa <90268099+NevsTD-MARZ@users.noreply.github.com>
    
    commit 2675a4d7f7cde92ead49cfda4a60f2b08dc41550
    Author: alejcabrera <acabrera@monstersaliensrobotszombies.com>
    Date:   Mon Dec 13 16:50:45 2021 -0500
    
        Added new compiled and python bindings for compatibility between opencolorio and python 3.7
    
    commit 4c22713fa8e6cc0449150db717c372a842b60a6b
    Author: marz-machine-user <marz-machine-user@monstersaliensrobotszombies.com>
    Date:   Thu Dec 9 17:47:11 2021 -0500
    
        Automated commit: copy files from repo marzvfx/github_automation
    
        The above repo has been updated, triggering automation that copies
        and commits the updates to other repos, including this one.
    
        The commit SHA from marzvfx/github_automation that triggered
        this automation is: ec184366364d01536b01f117466891ad388e61f7
        (https://github.com/marzvfx/github_automation/commit/ec184366364d01536b01f117466891ad388e61f7)
    
    commit df3e9eb0528d4732040ec1f779becdd189d20c32
    Author: marz-machine-user <marz-machine-user@monstersaliensrobotszombies.com>
    Date:   Thu Dec 9 17:40:48 2021 -0500
    
        Automated commit: copy files from repo marzvfx/github_automation
    
        The above repo has been updated, triggering automation that copies
        and commits the updates to other repos, including this one.
    
        The commit SHA from marzvfx/github_automation that triggered
        this automation is: 343821f9eb0beb62fbec82bf88cb50ae19df4a0f
        (https://github.com/marzvfx/github_automation/commit/343821f9eb0beb62fbec82bf88cb50ae19df4a0f)
    
    commit 487fd8a3aabd2046056e108ec35eb1367854d63e
    Merge: 107d3bc 715503e
    Author: Guillermo Molina <gmolinart@gmail.com>
    Date:   Thu Dec 9 10:40:53 2021 -0400
    
        Merge pull request #1 from marzvfx/hotfix/python_37_bindings
    
        python 37 bindings
    
    commit 715503e1adaa82fcc21b35291e106d9fe0a40d60
    Author: alejcabrera <acabrera@monstersaliensrobotszombies.com>
    Date:   Thu Dec 9 09:14:00 2021 -0500
    
        addressed python bindings and increased rez version
    
    commit c77f80c1ff2652bfcb465eb1981d3ceb2e9d1fcb
    Author: Guillermo Molina <gmolinart@gmail.com>
    Date:   Tue Dec 7 16:05:31 2021 -0500
    
        initial commit with Ale and Nevil
    
    commit 63d13157ed3f48666d4ce99a3ab780eb180dfc4f
    Author: Guillermo Molina <gmolinart@gmail.com>
    Date:   Tue Dec 7 16:04:10 2021 -0500
    
        initial commit with Ale and Nevil
    
    commit 107d3bc081cc6d21171a0a693fd6228aa4516a74
    Author: Guillermo Molina <gmolinart@gmail.com>
    Date:   Tue Dec 7 15:14:20 2021 -0500
    
        Update README.md
    
    commit eea1acf421a1cdbea0570a8aebc60601f1b8b39e
    Author: Guillermo Molina <gmolinart@gmail.com>
    Date:   Tue Dec 7 14:11:34 2021 -0500
    
        Initial commit
    """

vcs = 'git'

revision = \
    {'branch': 'main',
     'commit': '75a250cec10d1f0d56ce83545a0f9af92d3fe8ce',
     'fetch_url': 'https://github.com/marzvfx/OpenImageIO.git',
     'push_url': 'https://github.com/marzvfx/OpenImageIO.git',
     'tracking_branch': 'origin/main'}

build_archive_filename = '2.1.9.0.zip'

root_items_to_build = ['README.md']

format_version = 2
